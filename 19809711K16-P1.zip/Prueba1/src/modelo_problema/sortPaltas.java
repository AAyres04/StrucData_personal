/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo_problema;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author souriez
 */
public class sortPaltas {
    
    public ArrayList<ModeloPalta> mergeSort(ArrayList<ModeloPalta> paltas){
        Collections.sort(paltas);
        return paltas;
    }
    
}
